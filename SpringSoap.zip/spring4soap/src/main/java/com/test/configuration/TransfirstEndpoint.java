package com.test.configuration;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import postilion.realtime.merchantframework.xsd.v1.SendTranRequest;
import postilion.realtime.merchantframework.xsd.v1.SendTranResponse;

@Endpoint
public class TransfirstEndpoint {
	private static final String NAMESPACE_URI = "http://postilion/realtime/merchantframework/xsd/v1/";
	

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "SendTranRequest")
	@ResponsePayload
	public SendTranResponse getCountry(@RequestPayload SendTranRequest request) {
		SendTranResponse response = new SendTranResponse();
		response.setRspCode("testt");
		return response;
	}
}
